package com.example.localllm.llm

import android.content.ContentResolver
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.codeshipping.llamakotlin.LlamaModel
import java.io.File
import java.io.FileOutputStream

class LlamaEngine(
    private val contentResolver: ContentResolver
) : InferenceEngine {

    private var model: LlamaModel? = null
    private var loaded = false

    override suspend fun loadModel(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val uri = Uri.parse(path)
            val localFile = File(
                contentResolver.appContext().cacheDir,
                "model.gguf"
            )

            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(localFile).use { output ->
                    input.copyTo(output, bufferSize = 8 * 1024 * 1024)
                }
            } ?: return@withContext Result.failure(
                IllegalStateException("Не могу открыть файл модели")
            )

            model = LlamaModel.load(localFile.absolutePath) {
                contextSize = 2048
                threads = 4
                temperature = 0.7f
            }
            loaded = true
            Result.success(Unit)

        } catch (e: Exception) {
            loaded = false
            Result.failure(e)
        }
    }

    override suspend fun generate(
        prompt: String,
        onToken: (String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        val currentModel = model
        if (!loaded || currentModel == null) {
            return@withContext Result.failure(IllegalStateException("Модель не загружена"))
        }

        try {
            val full = StringBuilder()
            currentModel.generateStream(prompt).collect { token ->
                full.append(token)
                onToken(token)
            }
            Result.success(full.toString())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun isLoaded(): Boolean = loaded

    override fun unload() {
        model?.close()
        model = null
        loaded = false
    }
}

private fun ContentResolver.appContext(): android.content.Context {
    val method = ContentResolver::class.java.getMethod("getContext")
    return method.invoke(this) as android.content.Context
}